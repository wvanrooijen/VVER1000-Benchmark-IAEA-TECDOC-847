#--------1---------2---------3---------4---------5---------6---------7--
#-----------------------------------------------------------------------
# This file is part of a set of input files for DONJON to simulate a
# VVER1000 nuclear reactor.
#
# These files are made available under the following license:
#
# Creative Commons Attribution - NonCommercial - ShareAlike 4.0
#                  International CC BY-NC-SA 4.0
#
# In short:
# Attribution: You must give appropriate credit, provide a link to the
#              license, and indicate if changes were made. You may do
#              so in any reasonable manner, but not in any way that
#              suggests the licensor endorses you or your use.
#
# NonCommercial: You may not use the material for commercial purposes.
#
# ShareAlike: If you remix, transform, or build upon the material, you
#             must distribute your contributions under the same license
#             as the original.
#
# The complete text of the licence is available in the file LICENSE.TXT
#
# The complete text of the license is available online:
#
#   https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode
#
# This set of files is made available in the hope that it will be use-
# ful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# If you publish work(s) based on calculations made with this set of
# DRAGON input files or derivatives thereof, please cite the following:
#
#
# W.F.G. van Rooijen, Md. J.H. khan, A. Hebert, V. Salino, "Analysis
# of a VVER-1000 in-core fuel management benchmark with DRAGON and
# DONJON", Journal of Nuclear Science and Technology, VV(n), ppp - ppp
# (2017)
#
#
# Copyright 2017 W.F.G. van Rooijen  University of Fukui, Japan
#------------------------------------------------------------------------------
import os as os
import numpy as np


def create_core_geometry(reactor, levels, fmap=False):
    """ __docstring__ """

    #--------------------------------------------------------------------------
    # Make a list of all elevations in the reactor, including the bottom
    # and top reflectors and the fuel layers
    #--------------------------------------------------------------------------
    z_fuel_top = 383.0
    z_fuel_bottom = 29.0

    z_axis = np.array([0.0, z_fuel_bottom, z_fuel_top, 403.0, 457.0])

    z_axis = np.append(z_axis, levels + z_fuel_bottom)

    z_axis = np.unique(z_axis)

    n_layers = len(z_axis) - 1
    n_fuel_layers = n_layers - 3

    #--------------------------------------------------------------------------
    # Core layout
    # T: terminal (bottom of SA)
    # R: radial reflector
    # A: 2.0 % fuel
    # B: 3.0 % fuel
    # C: 3.3 % fuel
    # D: profiled fuel
    # E: 3.0 % fuel with CR (bank X)
    # F: 3.0 % fuel with CR (bank X) shuffled in cycle 3
    # P: helium plenum region
    # Q: plenum region with control rod (bank X)
    # H: head (top of SA)
    #--------------------------------------------------------------------------
    n_fuel_rings = 7
    n_refl_rings = 1

    n_positions = 1

    for i in range(n_fuel_rings + n_refl_rings):
        n_positions += 6 * (i + 1)

    core_layout = {}

    strbuf = " T "

    for i in range(n_fuel_rings):
        strbuf += 6 * (i + 1) * " T "
    for i in range(n_fuel_rings, n_fuel_rings + n_refl_rings):
        strbuf += 6 * (i + 1) * " R "

    core_layout["bottom"] = strbuf

    strbuf = " H "

    for i in range(n_fuel_rings):
        strbuf += 6 * (i + 1) * " H "
    for i in range(n_fuel_rings, n_fuel_rings + n_refl_rings):
        strbuf += 6 * (i + 1) * " R "

    core_layout["top"] = strbuf

    core_layout["fuel"] = """
    A
    A
    A
    A
    A
    A
    A
    A B
    A B
    A B
    A B
    A B
    A B
    E A A
    E A A
    E A A
    E A A
    E A A
    E A A
    A A A A
    A A A A
    A A A A
    A A A A
    A A A A
    A A A A
    A B A A B
    A B A A B
    A B A A B
    A B A A B
    A B A A B
    A B A A B
    D B A B A B
    D B A B A B
    D B A B A B
    D B A B A B
    D B A B A B
    D B A B A B
    R C C F C C C
    R C C F C C C
    R C C F C C C
    R C C F C C C
    R C C F C C C
    R C C F C C C
    """

    for i in range(n_fuel_rings, n_fuel_rings + n_refl_rings):
        core_layout['fuel'] += 6 * (i + 1) * " R "

    core_layout["plenum"] = """
    P
    P
    P
    P
    P
    P
    P
    P P
    P P
    P P
    P P
    P P
    P P
    Q P P
    Q P P
    Q P P
    Q P P
    Q P P
    Q P P
    P P P P
    P P P P
    P P P P
    P P P P
    P P P P
    P P P P
    P P P P P
    P P P P P
    P P P P P
    P P P P P
    P P P P P
    P P P P P
    P P P P P P
    P P P P P P
    P P P P P P
    P P P P P P
    P P P P P P
    P P P P P P
    R P P P P P P
    R P P P P P P
    R P P P P P P
    R P P P P P P
    R P P P P P P
    R P P P P P P
    """

    for i in range(n_fuel_rings, n_fuel_rings + n_refl_rings):
        core_layout['plenum'] += 6 * (i + 1) * " R "

    fuel_types = ["A", "B", "C", "D", "E", "F"]

    #--------------------------------------------------------------------------
    #
    #--------------------------------------------------------------------------
    mixture_numbers = {}
    mix = 1

    for i in range(n_fuel_layers):
        for idd in core_layout["fuel"].split():
            if idd in mixture_numbers.keys():
                continue
            if not idd in fuel_types:
                continue
            idd = idd + "{:d}".format(i)
            if not idd in mixture_numbers.keys():
                mixture_numbers[idd] = mix
                mix += 1

    for layer in ["bottom", "plenum", "top"]:
        for idd in core_layout[layer].split():
            if not idd in mixture_numbers.keys():
                mixture_numbers[idd] = mix
                mix += 1

    #--------------------------------------------------------------------------
    # COMPO names
    #--------------------------------------------------------------------------
    compo_names = {}
    compo_names["A"] = "EDI2A"
    compo_names["B"] = "EDI2B"
    compo_names["C"] = "EDI2C"
    compo_names["D"] = "EDI2D"
    compo_names["E"] = "EDI2B"
    compo_names["F"] = "EDI2C"

    compo_names["H"] = "HEAD"
    compo_names["P"] = "PLEN"
    compo_names["Q"] = "QLEN"
    compo_names["R"] = "REFL"
    compo_names["T"] = "TERM"

    edit_level = 0

    #--------------------------------------------------------------------------
    # The geometry input and the fuel map are more or less the same, so here
    # we select which file we need to write.
    #--------------------------------------------------------------------------
    if fmap:
        filename = "cfmap.c2m"
    else:
        filename = "cgeom.c2m"

    outfile = open(filename, "w")

    if fmap:
        outfile.write("PARAMETER   FLMAP MATEX :: ")
        outfile.write("::: LINKED_LIST FLMAP MATEX ; ;\n")
        outfile.write("MODULE      RESINI: END: ;\n")
    else:
        outfile.write("PARAMETER   GEOM :: ::: LINKED_LIST GEOM ; ;\n\n")
        outfile.write("MODULE      GEO: END: ;\n\n")

    outfile.write("!--------------------------------------------------------\n")
    outfile.write("! Reactor : {:s}\n".format(reactor))

    outfile.write("! Z-mesh:\n")
    for i in range(len(z_axis) - 1, -1, -1):
        outfile.write("! {:2d}  --  {:6.1f}\n".format(i + 1, z_axis[i]))

    outfile.write("! \n")
    outfile.write("! Core layout\n")
    outfile.write("! T: terminal (bottom of SA)\n")
    outfile.write("! R: radial reflector\n")
    outfile.write("! A: 2.0 % fuel\n")
    outfile.write("! B: 3.0 % fuel\n")
    outfile.write("! C: 3.3 % fuel\n")
    outfile.write("! D: profiled fuel\n")
    outfile.write("! E: 3.0 % fuel with CR (bank X)\n")
    outfile.write("! F: SA which will become a control rod in cycle 3\n")
    outfile.write("! P: helium plenum region\n")
    outfile.write("! Q: plenum region with control rod (bank X)\n")
    outfile.write("! H: head (top of SA)\n")
    outfile.write("! \n")
    outfile.write("! mixture numbers:\n")

    for m in sorted(mixture_numbers.keys()):
        outfile.write("!  {:2s}  {:3d}\n".format(m, mixture_numbers[m]))

    outfile.write("! \n")
    outfile.write("!--------------------------------------------------------\n")
    outfile.write("!--------------------------------------------------------\n")
    outfile.write("!  Ring #  |  # SAs   | total # SAs\n")
    outfile.write("!  ========+==========+============\n")
    outfile.write("!        0 |       1  |    1\n")
    outfile.write("!        1 |       6  |    7\n")
    outfile.write("!        2 |      12  |   19\n")
    outfile.write("!        3 |      18  |   37\n")
    outfile.write("!        4 |      24  |   61\n")
    outfile.write("!        5 |      30  |   91\n")
    outfile.write("!        6 |      36  |  127\n")
    outfile.write("!        7 |      42  |  169\n")
    outfile.write("!        8 |      48  |  217\n")
    outfile.write("!        9 |      54  |  271\n")
    outfile.write("!       10 |      60  |  331\n")
    outfile.write("!       11 |      66  |  397\n")
    outfile.write("!       12 |      72  |  469\n")
    outfile.write("!       13 |      78  |  566\n")
    outfile.write("!       14 |      84  |  650\n")
    outfile.write("!       15 |      90  |  760\n")
    outfile.write("!\n")
    outfile.write("! Correspondence between the SA positions\n")
    outfile.write("!  Benchmark   |   DONJON\n")
    outfile.write("!  position   ->   position\n")
    outfile.write("!  ========================\n")
    outfile.write("!         1   ->     1\n")
    outfile.write("!         2   ->     2\n")
    outfile.write("!         3   ->     8\n")
    outfile.write("!         4   ->    20\n")
    outfile.write("!         5   ->    38\n")
    outfile.write("!         6   ->    62\n")
    outfile.write("!         7   ->    92\n")
    outfile.write("!\n")
    outfile.write("!         8   ->     9\n")
    outfile.write("!         9   ->    21\n")
    outfile.write("!        10   ->    39\n")
    outfile.write("!        11   ->    63\n")
    outfile.write("!        12   ->    93\n")
    outfile.write("!        13   ->   129\n")
    outfile.write("!\n")
    outfile.write("!        14   ->    40\n")
    outfile.write("!        15   ->    64\n")
    outfile.write("!        16   ->    94\n")
    outfile.write("!        17   ->   130\n")
    outfile.write("!\n")
    outfile.write("!        18   ->    95\n")
    outfile.write("!        19   ->   131\n")
    outfile.write("!--------------------------------------------------------\n")

    SA_pitch = 23.80
    outfile.write("! SA pitch {:f}\n".format(SA_pitch))
    outfile.write("!--------------------------------------------------------\n")

    if fmap:
        outfile.write("FLMAP MATEX := RESINI: MATEX ::\n")
        outfile.write("EDIT 1\n")
        outfile.write("::: GEO: HEXZ {:d} {:d} EDIT {:d}\n".format(
            n_positions, n_layers, edit_level))
    else:
        outfile.write("GEOM := GEO: :: HEXZ {:d} {:d} EDIT {:d}\n".format(
            n_positions, n_layers, edit_level))
        outfile.write("  Z- VOID Z+ VOID\n")
        outfile.write("  HBC COMPLETE VOID\n")
    outfile.write("  SIDE {:f}\n".format(SA_pitch / np.sqrt(3.0)))
    outfile.write("  MIX\n")

    ctr = 0
    max_ctr = 20

    #--------------------------------------------------------------------------
    # Write bottom layer of geometry
    #--------------------------------------------------------------------------
    layer = "bottom"
    SA_types = core_layout[layer].replace(' ', '')

    outfile.write("!" + 79 * "-" + "\n")
    outfile.write("! Layer: {:s}".format(layer) + "\n")
    outfile.write("!" + 79 * "-" + "\n")

    outfile.write("! Ring 0\n")
    idx = 0
    SA = SA_types[idx]
    if fmap:
        outfile.write("{:3d}\n".format(0))
    else:
        outfile.write("{:3d}\n".format(mixture_numbers[SA]))

    for ring in range(1, n_fuel_rings + n_refl_rings + 1):
        outfile.write("! Ring {:d}\n".format(ring))
        outstr = ""
        for i in range(6):
            for j in range(ring):
                idx += 1
                SA = SA_types[idx]
                if fmap and not SA in fuel_types:
                    outstr += "{:3d}".format(0)
                else:
                    outstr += "{:3d}".format(mixture_numbers[SA])
            outstr += "\n"
        outfile.write(outstr)

    #--------------------------------------------------------------------------
    # Fuel layers
    #--------------------------------------------------------------------------
    layer = "fuel"
    SA_types = core_layout[layer].replace(' ', '').replace('\n', '')

    for zlayer in range(n_fuel_layers):
        outfile.write("!" + 79 * "-" + "\n")
        outfile.write("! Layer: {:s} {:d}".format(layer, zlayer + 1) + "\n")
        outfile.write("!" + 79 * "-" + "\n")

        outfile.write("! Ring 0\n")
        idx = 0

        SA = SA_types[idx]
        if SA in fuel_types:
            SA = SA + "{:d}".format(zlayer)
            outfile.write("{:3d}\n".format(mixture_numbers[SA]))
        else:
            if fmap:
                outfile.write("{:3d}\n".format(0))
            else:
                outfile.write("{:3d}\n".format(mixture_numbers[SA]))

        for ring in range(1, n_fuel_rings + n_refl_rings + 1):
            outfile.write("! Ring {:d}\n".format(ring))
            outstr = ""
            for i in range(6):
                for j in range(ring):
                    idx += 1
                    SA = SA_types[idx]
                    if SA in fuel_types:
                        SA = SA_types[idx] + "{:d}".format(zlayer)
                        outstr += "{:3d}".format(mixture_numbers[SA])
                    else:
                        if fmap:
                            outstr += "{:3d}".format(0)
                        else:
                            outstr += "{:3d}".format(mixture_numbers[SA])
                outstr += "\n"
            outfile.write(outstr)

    #--------------------------------------------------------------------------
    # Plenum layer
    #--------------------------------------------------------------------------
    layer = "plenum"
    SA_types = core_layout[layer].replace(' ', '').replace('\n', '')

    outfile.write("!" + 79 * "-" + "\n")
    outfile.write("! Layer: {:s}".format(layer) + "\n")
    outfile.write("!" + 79 * "-" + "\n")

    outfile.write("! Ring 0\n")
    idx = 0
    SA = SA_types[idx]
    if fmap:
        outfile.write("{:3d}\n".format(0))
    else:
        outfile.write("{:3d}\n".format(mixture_numbers[SA]))

    for ring in range(1, n_fuel_rings + n_refl_rings + 1):
        outfile.write("! Ring {:d}\n".format(ring))
        outstr = ""
        for i in range(6):
            for j in range(ring):
                idx += 1
                SA = SA_types[idx]
                if fmap and not SA in fuel_types:
                    outstr += "{:3d}".format(0)
                else:
                    outstr += "{:3d}".format(mixture_numbers[SA])
            outstr += "\n"
        outfile.write(outstr)

    #--------------------------------------------------------------------------
    # Top layer
    #--------------------------------------------------------------------------
    layer = "top"
    SA_types = core_layout[layer].replace(' ', '')

    outfile.write("!" + 79 * "-" + "\n")
    outfile.write("! Layer: {:s}".format(layer) + "\n")
    outfile.write("!" + 79 * "-" + "\n")

    outfile.write("! Ring 0\n")
    idx = 0
    SA = SA_types[idx]
    if fmap:
        outfile.write("{:3d}\n".format(0))
    else:
        outfile.write("{:3d}\n".format(mixture_numbers[SA]))

    for ring in range(1, n_fuel_rings + n_refl_rings + 1):
        outfile.write("! Ring {:d}\n".format(ring))
        outstr = ""
        for i in range(6):
            for j in range(ring):
                idx += 1
                SA = SA_types[idx]
                if fmap and not SA in fuel_types:
                    outstr += "{:3d}".format(0)
                else:
                    outstr += "{:3d}".format(mixture_numbers[SA])
            outstr += "\n"
        outfile.write(outstr)

    #--------------------------------------------------------------------------
    # Rest of geometry input
    #--------------------------------------------------------------------------
    outstr = "  MESHZ "
    max_ctr = 5
    ctr = 0

    for i in range(len(z_axis)):
        outstr += " {:.1f} ".format(z_axis[i])
        ctr += 1
        if ctr == max_ctr:
            outstr += "\n"
            outfile.write(outstr)
            ctr = 0
            outstr = ""

    outfile.write(outstr + "\n")

    #--------------------------------------------------------------------------
    # If geometry, then add the splitting of the mesh in axial direction,
    # if fuel map, assign a name to the fuel channels
    #--------------------------------------------------------------------------
    if not fmap:
        outstr = "  SPLITZ "

        ctr = 0
        nz = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2], int)

        for e in nz:
            outstr += " {:d} ".format(e)
            ctr += 1
            if ctr == max_ctr:
                outstr += "\n"
                outfile.write(outstr)
                ctr = 0
                outstr = ""

        outfile.write(outstr + "\n")
    else:
        outfile.write("  ;\n")

        SA_types = core_layout["fuel"].replace(" ", "").replace("\n", "")
        outfile.write("  NHNAME\n")

        outfile.write("  *-------------------------------------------\n")
        outfile.write("  * Ring 0\n")
        outfile.write("  *-------------------------------------------\n")
        nhname = "C00A01"
        outfile.write(nhname + "\n")

        SA_idx = 1

        for ring in range(1, n_fuel_rings + n_refl_rings + 1):
            outfile.write("  *-------------------------------------------\n")
            outfile.write("  * Ring {:d}\n".format(ring))
            outfile.write("  *-------------------------------------------\n")
            for sector in ["A", "B", "C", "D", "E", "F"]:
                outstr = ""
                for SA in range(ring):
                    nhname = "C{:02d}{:1s}{:02d} ".format(ring, sector, SA + 1)
                    if SA_types[SA_idx] in fuel_types:
                        outstr += nhname
                    else:
                        outstr += "- "
                    SA_idx += 1
                outfile.write(outstr + "\n")
                outstr = ""

        outfile.write("  NCOMB ALL\n")
        outfile.write("  BTYPE INST-BURN\n")
        outfile.write("  INST-BVAL SAME 0.0 \n")
        outfile.write("  BUNDLE-POW SAME 1840.0\n")
        outfile.write("  ADD-PARAM PNAME 'T-FUEL' PARKEY 'T-FUEL' LOCAL\n")
        outfile.write("  ADD-PARAM PNAME 'D-COOL' PARKEY 'D-COOL' LOCAL\n")
        outfile.write("  ADD-PARAM PNAME 'T-COOL' PARKEY 'T-COOL' LOCAL\n")
        outfile.write("  SET-PARAM 'T-FUEL' SAME {:.1f}\n".format(
            285.0 + 273.15))
        outfile.write("  SET-PARAM 'D-COOL' SAME {:.3f}\n".format(0.756))
        outfile.write("  SET-PARAM 'T-COOL' SAME {:.1f}\n".format(
            285.0 + 273.15))

        #----------------------------------------------------------------------
        # The FUEL WEIGHT is the weight of the heavy metal in the fuel. For
        # VVER1000, one fuel pin contains 1560 grams of fuel (UO2), so we
        # can calculate the mass of uranium in one assembly as below.
        #----------------------------------------------------------------------
        SA_fuel_mass = 1560.0 * 312.0 * 237.9 / (1000.0 * 270.0)
        SA_fueled_length = z_fuel_top - z_fuel_bottom

        outfile.write("  FUEL WEIGHT\n")

        zlo = z_axis[1]

        for zhi in z_axis[2:]:
            if zlo == z_fuel_top:
                break
            fuel_weight = SA_fuel_mass * (zhi - zlo) / SA_fueled_length
            outstr = len(fuel_types) * " {:.1f} ".format(fuel_weight)
            outfile.write(outstr + "\n")
            zlo = zhi

    outfile.write("  ;\n\n")
    outfile.write("END: ;\n")
    outfile.write("QUIT \"LIST\" .\n")
    outfile.close()

    retval = {}
    retval["core_layout"] = core_layout
    retval["core_layers"] = levels
    retval["n_fuel_layers"] = n_fuel_layers
    retval["fuel_types"] = fuel_types
    retval["mixture_numbers"] = mixture_numbers
    retval["compo_names"] = compo_names

    return retval


#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
def donjon_input_header(name, reactor, times):
    """ __docstring__ """

    separator = "\n"
    separator += "!" + 71 * "-" + "\n"
    separator += "!\n"
    separator += "!" + 71 * "-" + "\n"

    edit_level = 0

    outfile = open(name, "w")

    max_ctr = 5
    ctr = 0

    outfile.write("PROCEDURE    cgeom  cfmap \n")

    outstr = "  "

    for i in range(len(times)):
        for j in range(len(times[i])):
            outstr += " cbor{:d}_{:d} ".format(i + 1, j + 1)
            ctr += 1
            if ctr == max_ctr:
                outfile.write(outstr + "\n")
                outstr = "  "
                ctr = 0

    outfile.write(outstr + ";\n")
    outfile.write(separator)

    outfile.write("LINKED_LIST  GEOM    MATEX   FLMAP  ")
    outfile.write("MACRO1     MACRO2  MACFL\n")
    outfile.write("             TRACK   SYSTEM  FLUX   ")
    outfile.write("NONFUELDB  FUELDB  POWER\n")
    outfile.write("             DBRHS   CORETH ;\n")
    outfile.write(separator)

    outfile.write("MODULE COMPO:  USPLIT: NCR:   MACINI: DELETE: ")
    outfile.write("TRIVAT: TRIVAA: FLUD: \n")
    outfile.write("       FLPOW:  GREP:   TINST: END: ;\n")
    outfile.write(separator)

    outfile.write("SEQ_ASCII  dbase_file1 :: FILE 'VVER_A.COMPO' ;\n")
    outfile.write("SEQ_ASCII  dbase_file2 :: FILE 'VVER_B.COMPO' ;\n")
    outfile.write("SEQ_ASCII  dbase_file3 :: FILE 'VVER_C.COMPO' ;\n")
    outfile.write("SEQ_ASCII  dbase_file4 :: FILE 'VVER_D.COMPO' ;\n")
    outfile.write("SEQ_ASCII  dbase_nfuel :: FILE 'NONFUEL.COMPO' ;\n")
    outfile.write(separator)

    outfile.write("FUELDB := COMPO: :: EDIT {:d}\n".format(edit_level))

    for SA in ["A", "B", "C", "D"]:
        outfile.write("  STEP UP 'EDI2{:s}'\n".format(SA))
        outfile.write("    COMM  'SA TYPE {:s}' ENDC\n".format(SA))
        outfile.write("    PARA  'BURN'    IRRA\n")
        outfile.write("    PARA  'T-FUEL'  VALU REAL\n")
        outfile.write("    PARA  'D-COOL'  VALU REAL\n")
        outfile.write("    PARA  'C-BORE'  VALU REAL\n")
        outfile.write("    PARA  'CCR'     VALU REAL\n")
        outfile.write("    INIT \n")

    outfile.write(";\n")
    outfile.write(separator)

    outfile.write("DBRHS := dbase_file1 ;\n")

    outfile.write("FUELDB := COMPO: FUELDB DBRHS :: EDIT 0\n")
    outfile.write("  STEP UP 'EDI2A' ; \n")

    outfile.write("DBRHS := DELETE: DBRHS ;\n")

    outfile.write(separator)
    outfile.write("DBRHS := dbase_file2 ;\n")

    outfile.write("FUELDB := COMPO: FUELDB DBRHS :: EDIT 0\n")
    outfile.write("  STEP UP 'EDI2B' ; \n")

    outfile.write("DBRHS := DELETE: DBRHS ;\n")

    outfile.write(separator)
    outfile.write("DBRHS := dbase_file3 ;\n")

    outfile.write("FUELDB := COMPO: FUELDB DBRHS :: EDIT 0\n")
    outfile.write("  STEP UP 'EDI2C' ; \n")

    outfile.write("DBRHS := DELETE: DBRHS ;\n")

    outfile.write(separator)
    outfile.write("DBRHS := dbase_file4 ;\n")

    outfile.write("FUELDB := COMPO: FUELDB DBRHS :: EDIT 0\n")
    outfile.write("  STEP UP 'EDI2D' ; \n")

    outfile.write("DBRHS := DELETE: DBRHS ;\n")

    outfile.write(separator)
    outfile.write("NONFUELDB := dbase_nfuel ;\n")
    outfile.write(separator)


#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
def donjon_input_main(name, reactor, cycle, core_data, times,
    cr_positions, cr_type, power_levels, mdot, t_inlet, proc_dir):
    """ __docstring__ """

    core_layout = core_data["core_layout"]
    core_layers = core_data["core_layers"]
    mixture_numbers = core_data["mixture_numbers"]
    fuel_types = core_data["fuel_types"]
    n_fuel_layers = core_data["n_fuel_layers"]

    edit_level = 0

    separator = "\n"
    separator += "!" + 71 * "-" + "\n"
    separator += "!\n"
    separator += "!" + 71 * "-" + "\n"

    outfile = open(x2m_name, "a")

    if cycle == 1:
        outfile.write("GEOM := cgeom ;\n")
        outfile.write(separator)

        outfile.write("GEOM MATEX := USPLIT: GEOM :: EDIT {:d}\n".format(
            edit_level))
        outfile.write("  NGRP 2 MAXR 20000\n")

    #--------------------------------------------------------------------------
    # Determine the number of non-fuel mixtures
    #--------------------------------------------------------------------------
        nonfuel_mixes = []
        buf = []

        for region in ["bottom", "top", "plenum"]:
            for ids in core_layout[region].split():
                buf.append(mixture_numbers[ids])

        for ids in core_layout["fuel"].split():
            if ids not in fuel_types:
                buf.append(mixture_numbers[ids])

        buf = set(buf)

        for i in buf:
            nonfuel_mixes.append(i)

        nonfuel_mixes = sorted(nonfuel_mixes)

        outstr = "  NREFL {:d} RMIX ".format(len(nonfuel_mixes))

        for i in nonfuel_mixes:
            outstr += "{:d} ".format(i)

        outfile.write(outstr + "\n")

    #--------------------------------------------------------------------------
    # Determine the number of fuel mixtures
    #--------------------------------------------------------------------------
        fuel_mixes = []
        buf = []

        for ids in core_layout["fuel"].split():
            if ids in fuel_types:
                for layer in range(n_fuel_layers):
                    buf.append(mixture_numbers[ids + "{:d}".format(layer)])

        buf = set(buf)

        for i in buf:
            fuel_mixes.append(i)

        fuel_mixes = sorted(fuel_mixes)

        outstr = "  NFUEL {:d} FMIX ".format(len(fuel_mixes))

        ctr = 0
        max_ctr = 5

        for i in fuel_mixes:
            outstr += "{:d} ".format(i)
            ctr += 1
            if ctr == max_ctr:
                outfile.write(outstr + "\n")
                outstr = "  "
                ctr = 0
        outfile.write(outstr + "\n")

        outfile.write("  ;\n")
        outfile.write(separator)

        outfile.write("FLMAP MATEX := cfmap MATEX ;\n")
        outfile.write(separator)

        FE_order = 2
        quadrature = 3
        split = 2
        spn = 0

        outfile.write("TRACK := TRIVAT: GEOM :: EDIT {:d}\n".format(edit_level))
        outfile.write("  MAXR 50000 DUAL {:d} {:d} {:d} \n".format(FE_order,
            quadrature, split))
        outfile.write("  SPN {:d} ; \n".format(spn))
        outfile.write(separator)

    #--------------------------------------------------------------------------
    # Assuming constant power between tabulated time points
    #--------------------------------------------------------------------------
    nominal_power = 3000.0

    dt = np.diff(times)
    rtimes = np.zeros((len(times), ), float)

    for i in range(len(dt)):
        rtimes[i + 1] = rtimes[i] + dt[i] * nominal_power / power_levels[i]

    for i in range(len(rtimes)):
        j = np.argmin((core_layers - cr_positions[i]) ** 2) + 1

        proc_name = "cbor{:d}_{:d}".format(cycle, i + 1)
        outfile.write("MATEX FLMAP := {:s} FUELDB NONFUELDB FLMAP"
            .format(proc_name))
        outfile.write(" MATEX TRACK ;\n")
        #outfile.write(separator)

        if i == len(times) - 1:
            bu_step = - 1
        else:
            bu_step = rtimes[i + 1] - rtimes[i]

        create_critbor_proc(proc_name, core_data, j, proc_dir,
            times[i], power_levels[i], mdot[i], t_inlet[i], cycle, cr_type,
            bu_step)

        if bu_step == - 1:
            break

    outfile.write(separator)


#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
def create_critbor_proc(proc_name, core_data, j, proc_dir,
    time, power, mdot, t_inlet, cycle, cr_type, bu_step):
    """ __docstring__ """

    compo_names = core_data["compo_names"]
    n_fuel_layers = core_data["n_fuel_layers"]
    mixture_numbers = core_data["mixture_numbers"]

    bconc_max = 1500.
    wt = 0.25
    wp = 0.25
    tol = 1.0e-3

    curdir = os.getcwd()

    os.chdir(proc_dir)

    separator = "\n"
    separator += "!" + 71 * "-" + "\n"
    separator += "!\n"
    separator += "!" + 71 * "-" + "\n"

    outfile = open(proc_name + ".c2m", "w")
    print("Writing file: ", proc_name + ".c2m")

    outfile.write("PARAMETER MATEX FLMAP FUELDB NONFUELDB TRACK :: \n")
    outfile.write("  EDIT 2 \n")
    outfile.write("  ::: LINKED_LIST MATEX FLMAP FUELDB NONFUELDB TRACK ; ;\n")
    outfile.write(separator)

    outfile.write("MODULE NCR: MACINI: TRIVAA: DELETE: FLUD: GREP: \n")
    outfile.write("       FLPOW: THM: TINST: END: ;\n")
    outfile.write(separator)

    outfile.write("LINKED_LIST MACFL MACRO1 MACRO2 SYSTEM CORETH POWER\n")
    outfile.write("            FLUX ;\n")
    outfile.write(separator)

    outfile.write("REAL  b10_dens b10_max \n")
    outfile.write("      x x1 x2 y y1 y2 yt dx dy der err err2 tol tol2\n")
    outfile.write("      erra1 dinlet doutlet mindcool maxdcool \n")
    outfile.write("            tinlet toutlet mintcool maxtcool ;\n")
    outfile.write(separator)

    outfile.write("INTEGER  keep_going  iter  max_iter thm_iter \n")
    outfile.write("         thm_max_iter ;\n")
    outfile.write("LOGICAL  CONV ;\n")
    outfile.write(separator)

    outfile.write("EVALUATE b10_max := {:.1f} ;\n".format(bconc_max))
    outfile.write("EVALUATE x1 := 0.0 ;\n")
    outfile.write("EVALUATE b10_dens := x1 ;\n")
    outfile.write("EVALUATE dinlet := 0.75 ;\n")
    outfile.write("EVALUATE doutlet := 0.75 ;\n")
    outfile.write("EVALUATE tinlet := {:.2f} ;\n".format(t_inlet + 273.15))
    outfile.write("EVALUATE toutlet := {:.2f} ;\n".format(t_inlet + 273.15))

    #--------------------------------------------------------------------------
    # Read non fuel materials from COMPO
    #--------------------------------------------------------------------------
    outfile.write("MACRO1 := NCR: NONFUELDB :: EDIT 0 MACRO\n")
    outfile.write("  NMIX {:d}\n".format(len(mixture_numbers.keys())))

    for ids in compo_names.keys():
        if ids in ["R", "T"]:
            outfile.write(
                "    COMPO NONFUELDB '{:s}' MIX {:d} \n".format(
                compo_names[ids], mixture_numbers[ids]))
            outfile.write("      SET 'C-BORE' <<b10_dens>> \n")
            outfile.write("      SET 'T-{:s}' <<tinlet>>\n".format(
                compo_names[ids]))
            outfile.write("      SET 'D-COOL' <<dinlet>> \n")
            outfile.write("      ENDMIX\n")
        if ids in ["P", "Q", "H"]:
            outfile.write(
                "    COMPO NONFUELDB '{:s}' MIX {:d} \n".format(
                compo_names[ids], mixture_numbers[ids]))
            outfile.write("      SET 'C-BORE' <<b10_dens>> \n")
            outfile.write("      SET 'T-{:s}' <<toutlet>>\n".format(
                compo_names[ids]))
            outfile.write("      SET 'D-COOL' <<doutlet>> \n")
            outfile.write("      ENDMIX\n")
    outfile.write("  ;\n")

    outfile.write(separator)

    outfile.write("MACFL := NCR: FUELDB FLMAP :: EDIT 0 MACRO\n")

    for t in ["A", "B", "C", "D", "E", "F"]:
        for l in range(n_fuel_layers):

            ccr = 0.0

            if t == cr_type and l >= j:
                ccr = 1.0

            cname = compo_names[t]
            mt = mixture_numbers[t + "{:d}".format(l)]

            outfile.write("  TABLE FUELDB {:s} 'BURN' MIX {:>2d} INST-BURN\n".format(cname, mt))
            outfile.write("    SET 'C-BORE' <<b10_dens>> SET 'CCR' {:.1f} ENDMIX\n".format(ccr))

    outfile.write("  ;\n")
    outfile.write(separator)

    outfile.write("MACRO2 MATEX := MACINI: MATEX MACRO1 MACFL :: EDIT 0 ;\n")
    outfile.write(separator)

    outfile.write("SYSTEM := TRIVAA: MACRO2 TRACK :: EDIT 0 ;\n")
    outfile.write(separator)

    #outfile.write("FLUX := FLUD: SYSTEM TRACK :: EDIT 0 ACCE 5 3 ADI 15 ;\n")
    outfile.write("FLUX := FLUD: SYSTEM TRACK :: EDIT 5 EXTE 15 ;\n")
    outfile.write(separator)

    outfile.write("GREP: FLUX :: GETVAL 'K-EFFECTIVE' 1 >>y1<< ;\n")
    outfile.write(separator)

    outfile.write("MACFL MACRO1 MACRO2 SYSTEM := DELETE: ")
    outfile.write("MACFL MACRO1 MACRO2 SYSTEM ;\n")
    outfile.write(separator)

    outfile.write("EVALUATE x2 := b10_max ;\n")
    outfile.write("EVALUATE b10_dens := x2 ;\n")

    #--------------------------------------------------------------------------
    # Read non fuel materials from COMPO
    #--------------------------------------------------------------------------
    outfile.write("MACRO1 := NCR: NONFUELDB :: EDIT 0 MACRO\n")
    outfile.write("  NMIX {:d}\n".format(len(mixture_numbers.keys())))

    for ids in compo_names.keys():
        if ids in ["R", "T"]:
            outfile.write(
                "    COMPO NONFUELDB '{:s}' MIX {:d} \n".format(
                compo_names[ids], mixture_numbers[ids]))
            outfile.write("      SET 'C-BORE' <<b10_dens>> \n")
            outfile.write("      SET 'T-{:s}' <<tinlet>>\n".format(
                compo_names[ids]))
            outfile.write("      SET 'D-COOL' <<dinlet>> \n")
            outfile.write("      ENDMIX\n")
        if ids in ["P", "Q", "H"]:
            outfile.write(
                "    COMPO NONFUELDB '{:s}' MIX {:d} \n".format(
                compo_names[ids], mixture_numbers[ids]))
            outfile.write("      SET 'C-BORE' <<b10_dens>> \n")
            outfile.write("      SET 'T-{:s}' <<toutlet>>\n".format(
                compo_names[ids]))
            outfile.write("      SET 'D-COOL' <<doutlet>> \n")
            outfile.write("      ENDMIX\n")
    outfile.write("  ;\n")

    outfile.write(separator)

    outfile.write("MACFL := NCR: FUELDB FLMAP :: EDIT 0 MACRO\n")

    for t in ["A", "B", "C", "D", "E", "F"]:
        for l in range(n_fuel_layers):

            ccr = 0.0

            if t == cr_type and l >= j:
                ccr = 1.0

            cname = compo_names[t]
            mt = mixture_numbers[t + "{:d}".format(l)]

            outfile.write("  TABLE FUELDB {:s} 'BURN' MIX {:>2d} INST-BURN\n".format(cname, mt))
            outfile.write("    SET 'C-BORE' <<b10_dens>> SET 'CCR' {:.1f} ENDMIX\n".format(ccr))

    outfile.write("  ;\n")
    outfile.write(separator)

    outfile.write("MACRO2 MATEX := MACINI: MATEX MACRO1 MACFL :: EDIT 0 ;\n")
    outfile.write(separator)

    outfile.write("SYSTEM := TRIVAA: MACRO2 TRACK :: EDIT 0 ;\n")
    outfile.write(separator)

    #outfile.write("FLUX := FLUD: FLUX SYSTEM TRACK :: EDIT 0 RELAX 0.8 ;\n")
    outfile.write("FLUX := FLUD: FLUX SYSTEM TRACK :: EDIT 5 EXTE 15 ;\n")
    outfile.write(separator)

    outfile.write("GREP: FLUX :: GETVAL 'K-EFFECTIVE' 1 >>y2<< ;\n")

    outfile.write("POWER FLMAP := FLPOW: FLMAP FLUX TRACK MATEX :: EDIT 0 PTOT {:.1f} ;\n".format(power))
    outfile.write(separator)

    #--------------------------------------------------------------------------
    # Standard UO2 density: rho_t = 10.3 g/cm3
    # As used in the VVER fuel pin, effective density: rho_e = 9.81 g / cm3
    # Porosity: rho_e = (1 - p) * rho_t -> p = 1 - (rho_e / rho_t)
    # Pu fraction: set to 0, Pu fraction in fresh fuel
    #--------------------------------------------------------------------------
    rho_e = 9.81
    rho_t = 10.96
    hgap = 2.5e3

    outfile.write("CORETH FLMAP := THM: FLMAP :: \n")
    outfile.write("  EDIT 0\n")
    outfile.write("  CWSECT 4.37 {:.1f}\n".format(mdot))
    outfile.write("  ASSMB {:.3E}  312  19\n".format(0.2380 * 0.2380 *
        np.sqrt(3) / 2.0))
    outfile.write("  INLET 15.5E+06 <<tinlet>> \n")
    outfile.write("  RADIUS 3.8E-03 3.86E-03 4.55E-03 4.1E-03 \n")
    outfile.write("  POROS  {:.3E}  \n".format(1.0 - (rho_e / rho_t)))
    outfile.write("  HGAP {:.3E} \n".format(hgap))
    outfile.write("  ; \n")
    outfile.write("\n")
    outfile.write("GREP: CORETH :: GETVAL 'MIN-D-COOL' 1 >>mindcool<< ; \n")
    outfile.write("GREP: CORETH :: GETVAL 'MAX-D-COOL' 1 >>maxdcool<< ; \n")
    outfile.write("GREP: CORETH :: GETVAL 'MIN-T-COOL' 1 >>mintcool<< ; \n")
    outfile.write("GREP: CORETH :: GETVAL 'MAX-T-COOL' 1 >>maxtcool<< ; \n")
    outfile.write("EVALUATE toutlet := mintcool {:.3f} * maxtcool {:.3f} * + ; \n".format(wt, 1.0 - wt))
    outfile.write("EVALUATE doutlet := mindcool {:.3f} * maxdcool {:.3f} * + ; \n".format(wp, 1.0 - wp))
    outfile.write(separator)

    outfile.write("MACFL MACRO1 MACRO2 SYSTEM POWER := DELETE:\n")
    outfile.write("MACFL MACRO1 MACRO2 SYSTEM POWER ;\n")
    outfile.write(separator)

    outfile.write("EVALUATE yt := 1.0 ;\n")
    outfile.write("EVALUATE tol := {:.2E} ;\n".format(tol))
    outfile.write("EVALUATE tol2 := tol tol * ;\n")
    outfile.write("EVALUATE keep_going := 1 ;\n")
    outfile.write("EVALUATE iter := 1 ;\n")
    outfile.write("EVALUATE max_iter := 10 ;\n")

    outfile.write("WHILE keep_going 1 = DO\n")
    outfile.write("  EVALUATE dy := y2 y1 - ;\n")
    outfile.write("  EVALUATE dx := x2 x1 - ;\n")
    outfile.write("  EVALUATE der := dy dx / ;\n")

    outfile.write("  EVALUATE dy := yt y1 - ;\n")
    outfile.write("  EVALUATE dx := dy der / ;\n")

    outfile.write("  EVALUATE x := x1 dx + ;\n")

    outfile.write("  IF x b10_max >= THEN \n")
    outfile.write("    EVALUATE x := b10_max ; \n")
    outfile.write("  ENDIF ; \n")

    outfile.write("  IF x 0.0 <= THEN \n")
    outfile.write("    EVALUATE x := 0.0 ; \n")
    outfile.write("  ENDIF ; \n")

    outfile.write("  ECHO \"x1 y1\" x1 y1 ;\n")
    outfile.write("  ECHO \"x2 y2\" x2 y2 ;\n")
    outfile.write("  ECHO \"new x\" x ;\n")

    outfile.write("  EVALUATE b10_dens := x ;\n")
    outfile.write("  EVALUATE thm_iter := 1 ;\n")
    outfile.write("  EVALUATE thm_max_iter := 5 ;\n")
    outfile.write("\n")
    outfile.write("  REPEAT\n")

    #--------------------------------------------------------------------------
    # Read non fuel materials from COMPO
    #--------------------------------------------------------------------------
    outfile.write("    MACRO1 := NCR: NONFUELDB :: EDIT 0 MACRO\n")
    outfile.write("      NMIX {:d}\n".format(len(mixture_numbers.keys())))

    for ids in compo_names.keys():
        if ids in ["R", "T"]:
            outfile.write(
                "    COMPO NONFUELDB '{:s}' MIX {:d} \n".format(
                compo_names[ids], mixture_numbers[ids]))
            outfile.write("      SET 'C-BORE' <<b10_dens>> \n")
            outfile.write("      SET 'T-{:s}' <<tinlet>>\n".format(
                compo_names[ids]))
            outfile.write("      SET 'D-COOL' <<dinlet>> \n")
            outfile.write("      ENDMIX\n")
        if ids in ["P", "Q", "H"]:
            outfile.write(
                "    COMPO NONFUELDB '{:s}' MIX {:d} \n".format(
                compo_names[ids], mixture_numbers[ids]))
            outfile.write("      SET 'C-BORE' <<b10_dens>> \n")
            outfile.write("      SET 'T-{:s}' <<toutlet>>\n".format(
                compo_names[ids]))
            outfile.write("      SET 'D-COOL' <<doutlet>> \n")
            outfile.write("      ENDMIX\n")
    outfile.write("  ;\n")

    outfile.write(separator)

    outfile.write("    MACFL := NCR: FUELDB FLMAP :: EDIT 0 MACRO\n")

    for t in ["A", "B", "C", "D", "E", "F"]:
        for l in range(n_fuel_layers):

            ccr = 0.0

            if t == cr_type and l >= j:
                ccr = 1.0

            cname = compo_names[t]
            mt = mixture_numbers[t + "{:d}".format(l)]

            outfile.write("      TABLE FUELDB {:s} 'BURN' MIX {:d} INST-BURN\n".format(cname, mt))
            outfile.write("        SET 'C-BORE' <<b10_dens>> SET 'CCR' {:.1f} ENDMIX\n".format(ccr))

    outfile.write("  ;\n")
    outfile.write(separator)

    outfile.write("    MACRO2 MATEX := MACINI: MATEX MACRO1 MACFL :: EDIT 0 ;\n")
    outfile.write(separator)

    outfile.write("    SYSTEM := TRIVAA: MACRO2 TRACK :: EDIT 0 ;\n")
    outfile.write(separator)

    outfile.write("    FLUX := FLUD: FLUX SYSTEM TRACK :: EDIT 5 EXTE 15 ;\n")
    outfile.write(separator)

    outfile.write("    POWER FLMAP := FLPOW: FLMAP FLUX TRACK MATEX :: EDIT 0")
    outfile.write("      \nPTOT {:.1f} ;\n".format(power))
    outfile.write("\n")
    outfile.write("    CORETH FLMAP := THM: CORETH FLMAP :: EDIT 0 ; \n")
    outfile.write("    GREP: CORETH :: GETVAL 'ERROR-T-FUEL' 1 >>erra1<< ;\n")
    outfile.write("    GREP: CORETH :: GETVAL 'MIN-D-COOL' 1 >>mindcool<< ; \n")
    outfile.write("    GREP: CORETH :: GETVAL 'MAX-D-COOL' 1 >>maxdcool<< ; \n")
    outfile.write("    GREP: CORETH :: GETVAL 'MIN-T-COOL' 1 >>mintcool<< ; \n")
    outfile.write("    GREP: CORETH :: GETVAL 'MAX-T-COOL' 1 >>maxtcool<< ; \n")
    outfile.write("    EVALUATE toutlet := mintcool {:.3f} * maxtcool {:.3f} * + ; \n".format(wt, 1.0 - wt))
    outfile.write("    EVALUATE doutlet := mindcool {:.3f} * maxdcool {:.3f} * + ; \n".format(wp, 1.0 - wp))
    outfile.write("\n")
    outfile.write("    EVALUATE CONV := erra1 1.0 < ;\n")
    outfile.write("    IF thm_iter thm_max_iter = THEN\n")
    outfile.write("      EVALUATE CONV := 0.0 1.0 < ;\n")
    outfile.write("    ENDIF ;\n")
    outfile.write("\n")
    outfile.write("    MACFL MACRO1 MACRO2 SYSTEM POWER := DELETE:\n      MACFL MACRO1 MACRO2 SYSTEM POWER ;\n")
    outfile.write("    EVALUATE thm_iter := thm_iter 1 + ;\n")
    outfile.write("  UNTIL CONV ;\n")

    outfile.write("  GREP: FLUX :: GETVAL 'K-EFFECTIVE' 1 >>y<< ;\n")
    outfile.write(separator)

    outfile.write("  ECHO \" ==== INFO ====\" ;\n")
    outfile.write("  ECHO \" THM: loop ended, ERROR-T-FUEL = \" erra1 ;\n")
    outfile.write("  ECHO \" THM_ITER / THM_MAX_ITER : \" thm_iter thm_max_iter ;\n")
    outfile.write("  ECHO \" ==== END ====\" ;\n")
    outfile.write("  EVALUATE err := y yt - ;\n")
    outfile.write("  EVALUATE err2 := err err * ;\n")
    outfile.write("  ECHO \"err2 tol2\" err2 tol2 ;\n")

    outfile.write("  IF err2 tol2 < THEN\n")
    outfile.write("    EVALUATE keep_going := 0 ;\n")
    outfile.write("    ECHO \"CONVERGED\" ;\n")
    outfile.write("  ELSEIF iter max_iter = THEN\n")
    outfile.write("    ECHO \"ERROR: max_iterations reached\" ;\n")
    outfile.write("    EVALUATE keep_going := 0 ;\n")
    outfile.write("  ELSEIF x b10_max >= THEN\n")
    outfile.write("    ECHO \"ERROR: max boron concentration reached\" ;\n")
    outfile.write("    ECHO \"ERROR: No solution possible\" ;\n")
    outfile.write("    EVALUATE keep_going := 0 ;\n")
    outfile.write("  ELSEIF x 0.0 <= THEN\n")
    outfile.write("    ECHO \"ERROR: min boron concentration reached\" ;\n")
    outfile.write("    ECHO \"ERROR: No solution possible\" ;\n")
    outfile.write("    EVALUATE keep_going := 0 ;\n")
    outfile.write("  ENDIF ;\n")

    outfile.write("  IF y y2 < THEN\n")
    outfile.write("    EVALUATE x2 := x ;\n")
    outfile.write("    EVALUATE y2 := y ;\n")
    outfile.write("  ELSE\n")
    outfile.write("    EVALUATE x1 := x ;\n")
    outfile.write("    EVALUATE y1 := y ;\n")
    outfile.write("  ENDIF ;\n")
    outfile.write("  EVALUATE iter := iter 1 + ;\n")
    outfile.write("ENDWHILE ;\n")

    outfile.write(separator)
    outfile.write("ECHO \"cycle {:d} time {:.1f} FPDs\" ;\n".format(cycle,
        time))
    outfile.write("ECHO \"k-eff \" y ;\n")
    outfile.write("ECHO \"B10 dens [g/kg H2O] \" b10_dens ;\n\n")
    outfile.write("ECHO \"power map at {:.1f} FPDs\" ;\n".format(time))
    outfile.write("POWER FLMAP := FLPOW: FLMAP FLUX TRACK MATEX ::\n")
    outfile.write("  EDIT 15 PTOT {:.1f} ;\n".format(power))

    if not bu_step == - 1:
        outfile.write("FLMAP := TINST: FLMAP POWER :: EDIT 0 TIME {:.1f} DAY ;\n".format(bu_step))

    outfile.write(separator)
    outfile.write("END: ;\n")
    outfile.write("QUIT \"LIST\" . \n")
    outfile.close()

    os.chdir(curdir)


#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
def donjon_input_shuffle(name, cycle, core_data):
    """ __docstring__ """

    sep1 = "!" + 71 * "-" + "\n"
    sep1 += "!\n"
    sep1 += "!" + 71 * "-" + "\n"

    sep2 = "  *" + 69 * "-" + "\n"
    sep2 += "  *\n"
    sep2 += "  *" + 69 * "-" + "\n"

    outfile = open(name, "a")

    outfile.write(sep1)

    new_fuel_type = "C"
    nfl = core_data["n_fuel_layers"]
    mixno = core_data["mixture_numbers"]

    if cycle == 1:
        outfile.write("FLMAP := TINST: FLMAP :: EDIT 0\n")
        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C01{:s}01 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C07{:s}03 TO C01{:s}01\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}03 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C02{:s}01 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C07{:s}06 TO C02{:s}01\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}06 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C03{:s}02 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C07{:s}04 TO C03{:s}02\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}04 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

            outfile.write("  SHUFF CHAN C03{:s}03 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C07{:s}05 TO C03{:s}03\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}05 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C05{:s}01 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C04{:s}03 TO C05{:s}01\n".format(p, p))
            outfile.write("  SHUFF CHAN C06{:s}04 TO C04{:s}03\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}04 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C05{:s}03 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C06{:s}02 TO C05{:s}03\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}02 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C05{:s}04 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C06{:s}06 TO C05{:s}04\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}06 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C04{:s}01 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C06{:s}01 TO C04{:s}01\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}01 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C04{:s}02 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C07{:s}02 TO C04{:s}02\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}02 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C04{:s}04 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C07{:s}07 TO C04{:s}04\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}07 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        outfile.write("  ;\n\n")
    elif cycle == 2:
        outfile.write(sep1)
        outfile.write("FLMAP := TINST: FLMAP :: EDIT 100\n")

        outfile.write("  SHUFF CHAN C00A01 TO POOL\n")
        outfile.write("  SHUFF CHAN C02A02 TO C00A01\n")
        outfile.write("  SHUFF CHAN C02B02 TO POOL\n")
        outfile.write("  SHUFF CHAN C02C02 TO POOL\n")
        outfile.write("  SHUFF CHAN C02D02 TO POOL\n")
        outfile.write("  SHUFF CHAN C02E02 TO POOL\n")
        outfile.write("  SHUFF CHAN C02F02 TO POOL\n")

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C02{:s}01 TO C02{:s}02\n".format(p, p))
            outfile.write("  SHUFF CHAN C06{:s}04 TO C02{:s}01\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}04 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C05{:s}01 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C01{:s}01 TO C05{:s}01\n".format(p, p))
            outfile.write("  SHUFF CHAN C06{:s}01 TO C01{:s}01\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}01 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C03{:s}01 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C03{:s}02 TO C03{:s}01\n".format(p, p))
            outfile.write("  SHUFF CHAN C07{:s}02 TO C03{:s}02\n".format(p, p))
            outfile.write("  SHUFF CHAN C04{:s}02 TO C07{:s}02\n".format(p, p))
            outfile.write("  SHUFF CHAN C07{:s}04 TO C04{:s}02\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}04 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C04{:s}03 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C03{:s}03 TO C04{:s}03\n".format(p, p))
            outfile.write("  SHUFF CHAN C07{:s}07 TO C03{:s}03\n".format(p, p))
            outfile.write("  SHUFF CHAN C04{:s}04 TO C07{:s}07\n".format(p, p))
            outfile.write("  SHUFF CHAN C07{:s}05 TO C04{:s}04\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}05 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C06{:s}03 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C05{:s}02 TO C06{:s}03\n".format(p, p))
            outfile.write("  SHUFF CHAN C07{:s}03 TO C05{:s}02\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}03 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C05{:s}03 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C06{:s}02 TO C05{:s}03\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}02 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C05{:s}04 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C06{:s}06 TO C05{:s}04\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C06{:s}06 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write(sep2)

        for p in ["A", "B", "C", "D", "E", "F"]:
            outfile.write("  SHUFF CHAN C06{:s}05 TO POOL\n".format(p))
            outfile.write("  SHUFF CHAN C05{:s}05 TO C06{:s}05\n".format(p, p))
            outfile.write("  SHUFF CHAN C07{:s}06 TO C05{:s}05\n".format(p, p))
            outfile.write("  NEWFUEL CHAN C07{:s}06 {:d} SOME".format(p, nfl))
            for l in range(nfl):
                ftype = "{:s}{:d}".format(new_fuel_type, l)
                outfile.write("{:3d}".format(mixno[ftype]))
            outfile.write("\n")

        outfile.write("  ;\n\n")

    cycle += 1
    return cycle


#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
def donjon_input_end(name):
    """ __docstring__ """

    outfile = open(x2m_name, "a")
    outfile.write("END: ;\n")
    outfile.write("QUIT \"LIST\" .")
    outfile.close()


#------------------------------------------------------------------------------
# This is where the program starts. Define reactor type, cycle, and the
# data to calculate the benchmark.
#------------------------------------------------------------------------------
donjon_name = "kalinin_public"
proc_ext = "c2m"
x2m_ext = "x2m"
proc_dir = donjon_name + "_proc"
x2m_name = donjon_name + "." + x2m_ext

reactor = "Kalinin VVER-1000"

core_layers = np.array([35.4, 70.8, 106.2, 141.6, 177.0, 212.4, 247.8, 283.2,
    318.6])

times = []

times.append(np.array([0.0, 6.4, 11.5, 17.0, 19.2, 27.5, 39.4, 47.3, 50.8, 58.1,
    58.8, 70.5, 72.0, 74.5, 84.6, 103.2, 123.5, 130.4, 132.7, 142.2, 154.8,
    165.7, 180.2, 197.8, 200.0, 235.0, 235.3]))

times.append(np.array([0.0, 5.0, 10.0, 13.6, 20.0, 25.0, 26.1, 27.0, 35.9, 68.3,
    78.1, 82.3, 92.0, 100.1, 110.9, 121.8, 155.1, 170.3, 200.0, 205.3, 208.0,
    214.8, 217.5, 238.0, 243.4, 265.8]))

times.append(np.array([0.0, 11.0, 19.9, 20.0, 37.0, 65.2, 86.2, 89.3, 90.2,
    95.2, 97.2, 117.7, 120.4, 147.0, 155.8, 160.7, 163.7, 173.7, 182.8,
    188.6, 197.5, 200.0, 208.8, 211.7, 214.6, 215.0, 217.4, 221.8, 222.3]))

#------------------------------------------------------------------------------
# Check presence of directory for procs. Make the directory for the procs
# if it does not exist. Make the geometry proc, and the fuelmap proc.
#------------------------------------------------------------------------------
curdir = os.getcwd()

if not os.path.isdir(proc_dir):
    outstr = "Creating proc directory {:s}".format(proc_dir)
    os.makedirs(proc_dir)

os.chdir(proc_dir)

core_data = create_core_geometry(reactor, core_layers, fmap=False)

create_core_geometry(reactor, core_layers, fmap=True)

os.chdir(curdir)

#------------------------------------------------------------------------------
# First part of the input file for DONJON
#------------------------------------------------------------------------------
donjon_input_header(x2m_name, reactor, times)

cr_positions = np.array([212.4, 247.8, 212.4, 212.4, 177.0, 247.8, 247.8,
    283.2, 283.2, 247.8, 247.8, 177.0, 283.2, 283.2, 283.2, 283.2, 247.8,
    283.2, 247.8, 283.2, 247.8, 283.2, 318.6, 247.8, 283.2, 283.2, 283.2])

power_levels = np.array([1450., 1060., 1500., 1500., 1590., 1560., 2220.,
    1380., 2040., 1650., 2040., 1510., 1710., 1860., 2370., 2400., 2370., 1980.,
    2310., 2370., 1740., 2790., 3090., 1020., 3090., 3090., 3090.])

mdot = np.array([80000., 80000., 80000., 90000., 90000., 90000., 90000.,
    90000., 90000., 90000., 90000., 90000., 90000., 90000., 90000., 90000.,
    90000., 90000., 90000., 90000., 90000., 90000., 90000., 90000., 90000.,
    90000., 90000.])

t_inlet = np.array([283.4, 282.5, 283.4, 283.4, 283.7, 283.6, 285.0, 283.7,
    284.7, 283.8, 284.7, 281.1, 283.9, 284.2, 285.5, 285.5, 285.5, 285.5,
    285.3, 285.5, 283.9, 286.4, 287.2, 282.3, 287.2, 282.2, 287.2])

#------------------------------------------------------------------------------
# Add calculation for each time step
#------------------------------------------------------------------------------
cycle = 1

CR_type = "E"

donjon_input_main(x2m_name, reactor, cycle, core_data, times[cycle - 1],
    cr_positions, CR_type, power_levels, mdot, t_inlet, proc_dir)

#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------
cycle = donjon_input_shuffle(x2m_name, cycle, core_data)

cr_positions = np.array([247.8, 247.8, 247.8, 247.8, 247.8, 283.2, 247.8,
    247.8, 283.2, 283.2, 247.8, 247.8, 247.8, 283.2, 283.2, 283.2, 283.2,
    283.2, 283.2, 283.2, 283.2, 247.8, 247.8, 283.2, 283.2, 283.2])

power_levels = np.array([3000., 3000., 3000., 2910., 3000., 2070., 2670.,
    3000., 3000., 3000., 2220., 3000., 3000., 2850., 3000., 3000., 3000.,
    3000., 2190., 2700., 2700., 1950., 2700., 2700., 2700., 2700.])

mdot = np.array([81914., 81412., 81412., 81412., 81402., 81868., 83914.,
    83914., 83774., 84080., 83700., 83800., 84800., 84000., 83942., 83970.,
    83800., 84668., 85207., 84800., 84844., 85200., 85100., 83161., 83161.,
    83161.])

t_inlet = np.array([287.0, 287.0, 287.0, 286.7, 287.0, 284.4, 286.1, 287.0,
    287.0, 287.0, 285.1, 287.0, 287.0, 286.6, 287.0, 287.0, 287.0, 287.0,
    284.8, 286.2, 286.2, 284.5, 286.2, 286.2, 286.2, 286.2])

donjon_input_main(x2m_name, reactor, cycle, core_data, times[cycle - 1],
    cr_positions, CR_type, power_levels, mdot, t_inlet, proc_dir)

#------------------------------------------------------------------------------
# Add calculation for each time step
#------------------------------------------------------------------------------
cycle = donjon_input_shuffle(x2m_name, cycle, core_data)

cr_positions = np.array([283.2, 283.2, 283.2, 283.2, 141.6, 283.2, 318.6,
    141.6, 283.2, 318.6, 318.6, 318.6, 318.6, 318.6, 318.6, 283.2, 318.6,
    318.6, 318.6, 318.6, 318.6, 318.6, 318.6, 283.2, 318.6, 318.6, 318.6,
    318.6, 318.6])

power_levels = np.array([2390., 3030., 3030., 3030., 1810., 3010., 3000.,
    1420., 2970., 3000., 2900., 3000., 2910., 3000., 3000., 2790., 3000.,
    3000., 3030., 3030., 2430., 2850., 2970., 2850., 3030., 3030., 2790.,
    2610., 1860.])

mdot = np.array([91410., 91322., 91320., 93000., 93000., 91370., 91000., 91000.,
    91000., 92000., 96000., 91450., 91100., 91040., 91040., 91000., 91000.,
    91000., 91000., 91000., 91000., 92000., 93000., 92600., 92000., 92860.,
    92900., 93000., 93000.])

t_inlet = np.array([285.5, 287.1, 287.1, 287.1, 284.1, 287.0, 287.0, 280.0,
    284.9, 286.9, 287.0, 286.8, 287.0, 286.7, 287.0, 287.0, 286.4, 287.0, 287.0,
    287.1, 287.1, 285.5, 286.6, 286.9, 286.6, 287.1, 286.4, 286.0, 284.2])

#------------------------------------------------------------------------------
# Add calculation for each time step
#------------------------------------------------------------------------------
CR_type = "F"

donjon_input_main(x2m_name, reactor, cycle, core_data, times[cycle - 1],
    cr_positions, CR_type, power_levels, mdot, t_inlet, proc_dir)

donjon_input_end(x2m_name)

print("all done")
