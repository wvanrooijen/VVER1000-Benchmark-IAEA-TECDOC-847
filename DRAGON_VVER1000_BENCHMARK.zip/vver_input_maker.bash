#!/bin/bash
#-------------------------------------------------------------------------------
#  Name          : vver_input_maker.bash
#  Type          : BASH script
#  Use           : Set up the input files for the VVER-1000 calations with 
#                  DRAGON
#  Author        : W.F.G. van Rooijen
#
#  Procedure called as: ./vver_input_maker.bash
#
#  The VVER-1000 benchmark consists of 4 types of fuel assemblies, referred to 
#  as types "A", "B", "C", and "D". With DRAGON it is inconvenient to have 
#  multiple input files, because the input file name and the name of the 
#  directory holding the procedures must match. It is easier to create one 
#  "basic" input file from which input files for DRAGON are automatically gene-
#  rated for each type of assembly. Besides choosing the assembly type, the 
#  script also allows to set the reference temperatures of fuel, clad, and 
#  coolant, the reference coolant density, and the reference boron concentra-
#  tion. This is convenient to perform calculations for the various steps of the
#  neutronics benchmark.
#-------------------------------------------------------------------------------

function mdi {
    echo "Making input for SA type " $iSA

    #---------------------------------------------------------------------
    # Set up DRAGON input
    #---------------------------------------------------------------------
    sed s/__SATYPE__/$1/ < "$path/$basename.base" > "$path/$basename.out"
    mv "$path/$basename.out" "$path/$basename.in"

    sed s/__TFUEL__/$2/ < "$path/$basename.in" > "$path/$basename.out"
    mv "$path/$basename.out" "$path/$basename.in"

    sed s/__TCLAD__/$3/ < "$path/$basename.in" > "$path/$basename.out"
    mv "$path/$basename.out" "$path/$basename.in"

    sed s/__TMODE__/$4/ < "$path/$basename.in" > "$path/$basename.out"
    mv "$path/$basename.out" "$path/$basename.in"

    sed s/__DENS_MODE__/$5/ < "$path/$basename.in" > "$path/$basename.out"
    mv "$path/$basename.out" "$path/$basename.in"

    sed s/__BCONC__/$6/ < "$path/$basename.in" > "$path/$basename.out"
    mv "$path/$basename.out" "$path/$basename.x2m"
    
    rm -f "$path/$basename.in"

    nice -n $NICE_LEVEL ./rdragon -w $basename.x2m > "${1}_${2}_${3}_${4}.result" &
    sleep 2
}

#-------------------------------------------------------------------------------
# Start of execution
#-------------------------------------------------------------------------------
NICE_LEVEL=10

#-------------------------------------------------------------------------------
# Select SA types for which to perform calculations
#-------------------------------------------------------------------------------
SA_list=("A" "B" "C" "D")

#-------------------------------------------------------------------------------
# Directory where the DRAGON input files reside
#-------------------------------------------------------------------------------
path="data"

#-------------------------------------------------------------------------------
# Base name of the input files
#-------------------------------------------------------------------------------
basename="VVER1000_benchmark"

#-------------------------------------------------------------------------------
# Example of a calculation with fuel temperature 830 C, cladding temperature and
# coolant temperature 302 C, moderator density of 724.3 kg/m3, and a boron
# concentration of 600 ppm in the coolant. Note that the rdragon script takes
# care of the generation of a unique temporary directory name for execution. 
#-------------------------------------------------------------------------------
for iSA in ${SA_list[@]} 
do
    mdi $iSA 830.0 302.0 302.0 724.3 600.0
done

